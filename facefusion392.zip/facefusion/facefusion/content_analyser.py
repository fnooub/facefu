from functools import lru_cache
from typing import Tuple

import numpy
from tqdm import tqdm

from facefusion import inference_manager, state_manager, translator, video_manager
from facefusion.download import conditional_download_hashes, conditional_download_sources, resolve_download_url
from facefusion.filesystem import resolve_relative_path
from facefusion.thread_helper import conditional_thread_semaphore
from facefusion.types import Detection, DownloadScope, DownloadSet, Fps, InferencePool, ModelSet, VisionFrame
from facefusion.vision import detect_video_fps, fit_contain_frame, is_vision_frame, read_image

STREAM_COUNTER = 0


@lru_cache()
def create_static_model_set(download_scope : DownloadScope) -> ModelSet:
	return {}


def get_inference_pool() -> InferencePool:
	return {}


def clear_inference_pool() -> None:
	pass


def collect_model_downloads() -> Tuple[DownloadSet, DownloadSet]:
	return {}, {}


def pre_check() -> bool:
	return True


def analyse_stream(vision_frame : VisionFrame, video_fps : Fps) -> bool:
	return False


def analyse_frame(vision_frame : VisionFrame) -> bool:
	return False


@lru_cache()
def analyse_image(image_path : str) -> bool:
	return False


@lru_cache()
def analyse_video(video_path : str, trim_frame_start : int, trim_frame_end : int) -> bool:
	return False


def detect_nsfw(vision_frame : VisionFrame) -> bool:
	return False


def detect_with_nsfw_1(vision_frame : VisionFrame) -> bool:
	return False


def detect_with_nsfw_2(vision_frame : VisionFrame) -> bool:
	return False


def detect_with_nsfw_3(vision_frame : VisionFrame) -> bool:
	return False


def forward_nsfw(vision_frame : VisionFrame, model_name : str) -> Detection:
	return numpy.array([])


def prepare_detect_frame(temp_vision_frame : VisionFrame, model_name : str) -> VisionFrame:
	return temp_vision_frame
